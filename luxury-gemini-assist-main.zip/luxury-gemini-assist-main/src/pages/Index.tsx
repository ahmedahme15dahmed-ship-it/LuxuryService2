import { useState } from "react";
import LoadingScreen from "@/components/LoadingScreen";
import ChatInterface from "@/components/ChatInterface";

const Index = () => {
  const [isLoading, setIsLoading] = useState(true);

  const handleLoadingComplete = () => {
    setIsLoading(false);
  };

  if (isLoading) {
    return <LoadingScreen onComplete={handleLoadingComplete} />;
  }

  return <ChatInterface />;
};

export default Index;
