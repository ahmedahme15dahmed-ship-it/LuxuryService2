// Luxury AI - Independent AI Model
// This is the core AI model file that handles all AI processing independently

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  fileAttachment?: FileData;
}

export interface FileData {
  name: string;
  type: string;
  content: string;
  size: number;
}

class LuxuryAI {
  private memory: ChatMessage[] = [];
  private knowledgeBase: Map<string, any> = new Map();

  constructor() {
    this.initializeKnowledgeBase();
  }

  private initializeKnowledgeBase() {
    // Initialize with programming knowledge
    this.knowledgeBase.set('lua', {
      keywords: ['function', 'end', 'if', 'then', 'else', 'for', 'while', 'do', 'repeat', 'until', 'local', 'return'],
      patterns: {
        function: /function\s+(\w+)\s*\(/g,
        variable: /local\s+(\w+)/g,
        comment: /--.*$/gm
      },
      help: {
        syntax: 'Lua syntax help and best practices',
        functions: 'Built-in Lua functions and libraries',
        debugging: 'Common Lua debugging techniques'
      }
    });

    this.knowledgeBase.set('javascript', {
      keywords: ['function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'async', 'await'],
      patterns: {
        function: /function\s+(\w+)\s*\(/g,
        arrow: /const\s+(\w+)\s*=\s*\(/g,
        variable: /(const|let|var)\s+(\w+)/g
      }
    });

    // Add more language support
    this.addLanguageSupport();
  }

  private addLanguageSupport() {
    const languages = {
      python: { extension: '.py', keywords: ['def', 'class', 'import', 'if', 'else', 'for', 'while'] },
      java: { extension: '.java', keywords: ['class', 'public', 'private', 'static', 'void'] },
      cpp: { extension: '.cpp', keywords: ['#include', 'int', 'void', 'class', 'namespace'] },
      html: { extension: '.html', keywords: ['<!DOCTYPE', '<html>', '<head>', '<body>'] },
      css: { extension: '.css', keywords: ['@media', 'color', 'background', 'margin', 'padding'] }
    };

    Object.entries(languages).forEach(([lang, data]) => {
      this.knowledgeBase.set(lang, data);
    });
  }

  async processMessage(message: string, fileData?: FileData): Promise<string> {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date(),
      fileAttachment: fileData
    };

    this.memory.push(userMessage);

    // Process the message and generate response
    const response = await this.generateResponse(message, fileData);
    
    const assistantMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response,
      timestamp: new Date()
    };

    this.memory.push(assistantMessage);
    return response;
  }

  private async generateResponse(message: string, fileData?: FileData): Promise<string> {
    const lowerMessage = message.toLowerCase();

    // Handle file analysis
    if (fileData) {
      return this.analyzeFile(fileData, message);
    }

    // Handle greetings
    if (this.isGreeting(lowerMessage)) {
      return this.getGreetingResponse();
    }

    // Handle coding questions
    if (this.isCodingQuestion(lowerMessage)) {
      return this.getCodingHelp(message);
    }

    // Handle file-related questions
    if (this.isFileQuestion(lowerMessage)) {
      return this.getFileHelp();
    }

    // Default intelligent response
    return this.getIntelligentResponse(message);
  }

  private isGreeting(message: string): boolean {
    const greetings = ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good evening', 'مرحبا', 'أهلا', 'السلام عليكم'];
    return greetings.some(greeting => message.includes(greeting));
  }

  private getGreetingResponse(): string {
    const responses = [
      "مرحباً بك في Luxury AI! 💎 أنا هنا لمساعدتك في البرمجة وتحليل الملفات. كيف يمكنني خدمتك اليوم؟",
      "أهلاً وسهلاً! 🌟 أنا مساعدك الذكي المتخصص في البرمجة. ارفع أي ملف كود وسأساعدك في فهمه وتطويره.",
      "السلام عليكم! ✨ مرحباً بك في عالم Luxury AI حيث البرمجة تلتقي بالذكاء الاصطناعي المتقدم."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private isCodingQuestion(message: string): boolean {
    const codingKeywords = ['code', 'function', 'variable', 'loop', 'syntax', 'error', 'debug', 'algorithm', 'كود', 'برمجة', 'خطأ', 'دالة'];
    return codingKeywords.some(keyword => message.includes(keyword));
  }

  private getCodingHelp(message: string): string {
    const responses = [
      "🔧 أستطيع مساعدتك في حل مشاكل البرمجة! ارفع ملف الكود وسأقوم بتحليله وإعطائك اقتراحات للتحسين.",
      "💻 سأكون سعيداً لمساعدتك! يمكنني تحليل أكواد Lua, JavaScript, Python, C++, وغيرها. ما هي المشكلة التي تواجهها؟",
      "⚡ دعني أساعدك في البرمجة! أرفق الملف وسأقوم بفحصه وتقديم الحلول المناسبة مع شرح مفصل."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private isFileQuestion(message: string): boolean {
    const fileKeywords = ['file', 'upload', 'attach', 'ملف', 'رفع', 'إرفاق'];
    return fileKeywords.some(keyword => message.includes(keyword));
  }

  private getFileHelp(): string {
    return `📁 يمكنك رفع الملفات بسهولة! 

الصيغ المدعومة:
• .lua - ملفات Lua
• .js/.ts - JavaScript/TypeScript  
• .py - Python
• .java - Java
• .cpp/.c - C/C++
• .html/.css - Web files
• .txt - ملفات نصية

ببساطة اسحب الملف وأفلته في منطقة الرفع أو انقر لاختياره. سأقوم بتحليله فوراً! ⚡`;
  }

  private analyzeFile(fileData: FileData, userMessage: string): string {
    const fileExtension = this.getFileExtension(fileData.name);
    const language = this.detectLanguage(fileExtension);
    
    let analysis = `🔍 تحليل الملف: ${fileData.name}\n`;
    analysis += `📊 النوع: ${language}\n`;
    analysis += `📏 الحجم: ${this.formatFileSize(fileData.size)}\n\n`;

    // Analyze content based on language
    if (language === 'lua') {
      analysis += this.analyzeLuaCode(fileData.content);
    } else if (language === 'javascript' || language === 'typescript') {
      analysis += this.analyzeJavaScriptCode(fileData.content);
    } else {
      analysis += this.analyzeGeneralCode(fileData.content, language);
    }

    return analysis;
  }

  private getFileExtension(filename: string): string {
    return filename.split('.').pop()?.toLowerCase() || '';
  }

  private detectLanguage(extension: string): string {
    const languageMap: { [key: string]: string } = {
      'lua': 'lua',
      'js': 'javascript',
      'ts': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'c++',
      'c': 'c',
      'html': 'html',
      'css': 'css',
      'txt': 'text'
    };
    return languageMap[extension] || 'unknown';
  }

  private analyzeLuaCode(content: string): string {
    const functions = (content.match(/function\s+(\w+)/g) || []).length;
    const variables = (content.match(/local\s+\w+/g) || []).length;
    const comments = (content.match(/--.*$/gm) || []).length;
    
    let analysis = "🔧 تحليل كود Lua:\n";
    analysis += `• عدد الدوال: ${functions}\n`;
    analysis += `• المتغيرات المحلية: ${variables}\n`;
    analysis += `• التعليقات: ${comments}\n\n`;
    
    analysis += "📋 اقتراحات التحسين:\n";
    if (comments === 0) {
      analysis += "• أضف تعليقات توضيحية للكود\n";
    }
    if (functions > 0) {
      analysis += "• الكود منظم جيداً بالدوال\n";
    }
    
    return analysis;
  }

  private analyzeJavaScriptCode(content: string): string {
    const functions = (content.match(/function\s+\w+|const\s+\w+\s*=/g) || []).length;
    const variables = (content.match(/(const|let|var)\s+\w+/g) || []).length;
    
    let analysis = "⚡ تحليل كود JavaScript:\n";
    analysis += `• عدد الدوال: ${functions}\n`;
    analysis += `• المتغيرات: ${variables}\n\n`;
    
    analysis += "🚀 اقتراحات:\n";
    if (content.includes('var ')) {
      analysis += "• استخدم const/let بدلاً من var\n";
    }
    if (content.includes('async')) {
      analysis += "• كود غير متزامن - ممتاز!\n";
    }
    
    return analysis;
  }

  private analyzeGeneralCode(content: string, language: string): string {
    const lines = content.split('\n').length;
    const characters = content.length;
    
    let analysis = `📊 تحليل عام للملف (${language}):\n`;
    analysis += `• عدد الأسطر: ${lines}\n`;
    analysis += `• عدد الأحرف: ${characters}\n\n`;
    analysis += "✨ يمكنني مساعدتك في فهم وتطوير هذا الكود!";
    
    return analysis;
  }

  private formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' bytes';
    if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
    return Math.round(bytes / (1024 * 1024)) + ' MB';
  }

  private getIntelligentResponse(message: string): string {
    const responses = [
      "🤔 سؤال مثير للاهتمام! دعني أفكر... يمكنني مساعدتك بشكل أفضل إذا كان لديك ملف كود محدد. هل تريد رفع ملف؟",
      "💡 أفهم ما تقصده. كوني مساعد AI متخصص في البرمجة، يمكنني تقديم مساعدة أكثر دقة مع الملفات. شاركني الكود!",
      "✨ رائع! أنا هنا لمساعدتك. للحصول على أفضل النتائج، شاركني ملفات الكود التي تعمل عليها وسأقدم لك تحليلاً مفصلاً."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  getMemory(): ChatMessage[] {
    return this.memory;
  }

  clearMemory(): void {
    this.memory = [];
  }
}

// Export singleton instance
export const luxuryAI = new LuxuryAI();