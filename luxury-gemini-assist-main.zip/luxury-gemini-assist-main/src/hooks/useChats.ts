import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Database } from "@/integrations/supabase/types";

export type Chat = Database["public"]["Tables"]["chats"]["Row"];
export type Message = Database["public"]["Tables"]["messages"]["Row"];

export const useChats = () => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load all chats
  const loadChats = async () => {
    const { data } = await supabase
      .from("chats")
      .select("*")
      .order("updated_at", { ascending: false });
    
    if (data) {
      setChats(data);
      if (data.length > 0 && !currentChatId) {
        setCurrentChatId(data[0].id);
      }
    }
  };

  // Create new chat with auto-generated title
  const createNewChat = async (firstMessage: string, fileData?: any): Promise<string> => {
    setIsLoading(true);
    
    try {
      // Generate smart title based on message content
      const title = generateChatTitle(firstMessage, fileData);
      
      const { data: chat, error } = await supabase
        .from("chats")
        .insert({ title })
        .select()
        .single();

      if (error) throw error;

      setChats(prev => [chat, ...prev]);
      setCurrentChatId(chat.id);
      return chat.id;
    } finally {
      setIsLoading(false);
    }
  };

  // Save message to database
  const saveMessage = async (
    chatId: string, 
    content: string, 
    isUser: boolean = true,
    fileData?: { name: string; content: string }
  ) => {
    const { error } = await supabase
      .from("messages")
      .insert({
        chat_id: chatId,
        content,
        is_user: isUser,
        file_name: fileData?.name,
        file_content: fileData?.content
      });

    if (error) console.error("Error saving message:", error);
  };

  // Load messages for specific chat
  const loadMessages = async (chatId: string): Promise<Message[]> => {
    const { data } = await supabase
      .from("messages")
      .select("*")
      .eq("chat_id", chatId)
      .order("created_at", { ascending: true });
    
    return data || [];
  };

  // Generate smart chat title
  const generateChatTitle = (message: string, fileData?: any): string => {
    const lowerMessage = message.toLowerCase();
    
    if (fileData) {
      const fileExt = fileData.name.split('.').pop()?.toLowerCase();
      
      if (fileExt === 'lua' && (lowerMessage.includes('edit') || lowerMessage.includes('تعديل'))) {
        return "Edit Lua File";
      }
      if (fileExt === 'js' && (lowerMessage.includes('fix') || lowerMessage.includes('إصلاح'))) {
        return "Fix JavaScript Code";
      }
      if (fileExt === 'py' && (lowerMessage.includes('analyze') || lowerMessage.includes('تحليل'))) {
        return "Analyze Python Script";
      }
      
      // General file operations
      if (lowerMessage.includes('review') || lowerMessage.includes('مراجعة')) {
        return `Review ${fileExt?.toUpperCase()} File`;
      }
      if (lowerMessage.includes('debug') || lowerMessage.includes('تصحيح')) {
        return `Debug ${fileExt?.toUpperCase()} Code`;
      }
      
      return `${fileExt?.toUpperCase()} File Analysis`;
    }
    
    // Text-based titles
    if (lowerMessage.includes('help') || lowerMessage.includes('مساعدة')) {
      return "Programming Help";
    }
    if (lowerMessage.includes('explain') || lowerMessage.includes('شرح')) {
      return "Code Explanation";
    }
    if (lowerMessage.includes('create') || lowerMessage.includes('إنشاء')) {
      return "Create New Code";
    }
    
    // Default title from first few words
    const words = message.split(' ').slice(0, 3).join(' ');
    return words.length > 30 ? words.substring(0, 30) + '...' : words || "New Chat";
  };

  // Delete chat
  const deleteChat = async (chatId: string) => {
    await supabase.from("chats").delete().eq("id", chatId);
    setChats(prev => prev.filter(chat => chat.id !== chatId));
    
    if (currentChatId === chatId) {
      const remainingChats = chats.filter(chat => chat.id !== chatId);
      setCurrentChatId(remainingChats.length > 0 ? remainingChats[0].id : null);
    }
  };

  useEffect(() => {
    loadChats();
  }, []);

  return {
    chats,
    currentChatId,
    setCurrentChatId,
    isLoading,
    createNewChat,
    saveMessage,
    loadMessages,
    deleteChat,
    loadChats
  };
};