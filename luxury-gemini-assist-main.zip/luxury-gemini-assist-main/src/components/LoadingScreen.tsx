import { useState, useEffect } from "react";

const LoadingScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-background">
      <div className="text-center space-y-8">
        {/* Diamond Logo */}
        <div className="relative mx-auto w-32 h-32">
          <div className="diamond-spin absolute inset-0 bg-gradient-diamond rounded-lg transform rotate-45 shadow-diamond"></div>
          <div className="diamond-spin absolute inset-2 bg-gradient-silver rounded-lg transform rotate-45 delay-150"></div>
          <div className="diamond-spin absolute inset-4 bg-gradient-background rounded-lg transform rotate-45 delay-300"></div>
        </div>

        {/* Brand Name */}
        <div className="space-y-2">
          <h1 className="text-5xl font-bold luxury-text tracking-wider">
            LUXURY AI
          </h1>
          <p className="text-muted-foreground text-lg">
            Premium AI Assistant
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-80 mx-auto space-y-2">
          <div className="h-1 bg-secondary rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-silver transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground">
            Loading {progress}%
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;