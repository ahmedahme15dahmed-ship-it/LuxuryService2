import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { luxuryAI, ChatMessage, FileData } from "@/lib/luxuryAI";
import { useChats, Message } from "@/hooks/useChats";
import FileUpload from "./FileUpload";
import ChatSidebar from "./ChatSidebar";

const ChatInterface = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentFile, setCurrentFile] = useState<FileData | undefined>();
  const [dragOver, setDragOver] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  const { 
    chats, 
    currentChatId, 
    setCurrentChatId, 
    createNewChat, 
    saveMessage, 
    loadMessages 
  } = useChats();

  // Load messages when chat changes
  useEffect(() => {
    const loadCurrentChatMessages = async () => {
      if (currentChatId) {
        const dbMessages = await loadMessages(currentChatId);
        const convertedMessages: ChatMessage[] = dbMessages.map(msg => ({
          id: msg.id,
          role: msg.is_user ? "user" : "assistant",
          content: msg.content,
          timestamp: new Date(msg.created_at || ""),
          fileAttachment: msg.file_name ? {
            name: msg.file_name,
            type: "",
            content: msg.file_content || "",
            size: 0
          } : undefined
        }));
        setMessages(convertedMessages);
      } else {
        // Welcome message for new chats
        const welcomeMessage: ChatMessage = {
          id: "welcome",
          role: "assistant",
          content: "مرحباً بك في Luxury AI! 💎 أنا مساعدك الذكي للبرمجة. ارفع أي ملف كود وسأساعدك في فهمه وتطويره.",
          timestamp: new Date()
        };
        setMessages([welcomeMessage]);
      }
    };

    loadCurrentChatMessages();
  }, [currentChatId]);

  useEffect(() => {
    // Auto scroll to bottom
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle drag and drop on chat area
  const handleChatDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleChatDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleChatDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      const file = files[0];
      try {
        const content = await file.text();
        const fileData: FileData = {
          name: file.name,
          type: file.type,
          content,
          size: file.size
        };
        setCurrentFile(fileData);
      } catch (error) {
        console.error('Error reading file:', error);
      }
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() && !currentFile) return;

    setIsLoading(true);
    
    try {
      const messageContent = input || "تحليل الملف المرفق";
      
      // Create new chat if none exists
      let chatId = currentChatId;
      if (!chatId) {
        chatId = await createNewChat(messageContent, currentFile);
      }

      // Create and save user message
      const userMessage: ChatMessage = {
        id: Date.now().toString(),
        role: "user",
        content: messageContent,
        timestamp: new Date(),
        fileAttachment: currentFile
      };

      setMessages(prev => [...prev, userMessage]);
      
      // Save user message to database
      await saveMessage(chatId, messageContent, true, currentFile ? {
        name: currentFile.name,
        content: currentFile.content
      } : undefined);

      setInput("");

      // Get AI response
      const response = await luxuryAI.processMessage(messageContent, currentFile);
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // Save AI response to database
      await saveMessage(chatId, response, false);
      
      // Clear file after processing
      if (currentFile) {
        setCurrentFile(undefined);
      }
    } catch (error) {
      console.error('Error processing message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewChat = () => {
    setCurrentChatId(null);
    setMessages([]);
    setCurrentFile(undefined);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('ar-EG', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex h-screen bg-gradient-background">
      {/* Sidebar */}
      <ChatSidebar onNewChat={handleNewChat} />
      
      {/* Main Chat Area */}
      <div 
        className={`flex flex-col flex-1 relative ${
          dragOver ? 'bg-gradient-diamond/10' : ''
        }`}
        onDragOver={handleChatDragOver}
        onDragLeave={handleChatDragLeave}
        onDrop={handleChatDrop}
      >
      {/* Drag Overlay */}
      {dragOver && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-gradient-diamond/20 backdrop-blur-sm">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-silver rounded-full flex items-center justify-center shadow-glow mx-auto">
              <Upload className="w-10 h-10 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold luxury-text">أفلت الملف هنا</h3>
            <p className="text-muted-foreground">سيتم إرفاق الملف تلقائياً</p>
          </div>
        </div>
      )}
      {/* Header */}
      <div className="bg-gradient-card border-b border-border p-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-diamond rounded-lg flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold luxury-text">Luxury AI</h1>
            <p className="text-sm text-muted-foreground">مساعدك الذكي للبرمجة</p>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.map((message) => (
            <div key={message.id} className="message-slide-in">
              <div className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <Card className={`p-4 max-w-[80%] ${
                  message.role === 'user' 
                    ? 'bg-gradient-silver text-primary-foreground' 
                    : 'bg-gradient-card'
                }`}>
                  {message.fileAttachment && (
                    <div className="mb-2 p-2 bg-secondary/50 rounded text-xs">
                      📎 {message.fileAttachment.name}
                    </div>
                  )}
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">
                    {message.content}
                  </div>
                  <div className="text-xs opacity-70 mt-2">
                    {formatTimestamp(message.timestamp)}
                  </div>
                </Card>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <Card className="p-4 bg-gradient-card">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-100"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-200"></div>
                  <span className="text-sm text-muted-foreground mr-2">جاري التفكير...</span>
                </div>
              </Card>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* File Upload & Input */}
      <div className="p-4 bg-gradient-card border-t border-border">
        <div className="max-w-4xl mx-auto space-y-3">
          {/* Message Input */}
          <div className="flex space-x-2">
            <FileUpload
              onFileSelect={setCurrentFile}
              currentFile={currentFile}
              onRemoveFile={() => setCurrentFile(undefined)}
            />
            <Input
              placeholder="اكتب رسالتك هنا..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 bg-secondary/50 border-border focus:border-primary"
              disabled={isLoading}
            />
            <Button
              onClick={handleSendMessage}
              disabled={isLoading || (!input.trim() && !currentFile)}
              className="bg-gradient-silver text-primary-foreground hover:shadow-glow"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};

export default ChatInterface;