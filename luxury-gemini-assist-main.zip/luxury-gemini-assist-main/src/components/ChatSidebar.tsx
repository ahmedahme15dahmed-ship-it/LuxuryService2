import { Plus, MessageSquare, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { useChats, Chat } from "@/hooks/useChats";

interface ChatSidebarProps {
  onNewChat: () => void;
}

const ChatSidebar = ({ onNewChat }: ChatSidebarProps) => {
  const { chats, currentChatId, setCurrentChatId, deleteChat } = useChats();

  const formatDate = (date: string) => {
    const d = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (d.toDateString() === today.toDateString()) {
      return "اليوم";
    } else if (d.toDateString() === yesterday.toDateString()) {
      return "أمس";
    } else {
      return d.toLocaleDateString("ar-EG", { 
        month: "short", 
        day: "numeric" 
      });
    }
  };

  return (
    <div className="w-64 bg-gradient-card border-r border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <Button
          onClick={onNewChat}
          className="w-full bg-gradient-silver text-primary-foreground hover:shadow-glow"
        >
          <Plus className="w-4 h-4 ml-2" />
          شات جديد
        </Button>
      </div>

      {/* Chat List */}
      <ScrollArea className="flex-1 p-2">
        <div className="space-y-2">
          {chats.map((chat) => (
            <Card
              key={chat.id}
              className={`p-3 cursor-pointer transition-all hover:bg-secondary/50 group relative ${
                currentChatId === chat.id 
                  ? 'bg-gradient-silver/20 border-primary/50' 
                  : 'bg-secondary/20'
              }`}
              onClick={() => setCurrentChatId(chat.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4 text-primary flex-shrink-0" />
                    <h3 className="font-medium text-sm truncate luxury-text">
                      {chat.title}
                    </h3>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDate(chat.updated_at || chat.created_at || "")}
                  </p>
                </div>
                
                <Button
                  size="sm"
                  variant="ghost"
                  className="opacity-0 group-hover:opacity-100 transition-opacity w-6 h-6 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteChat(chat.id);
                  }}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          ))}
          
          {chats.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">لا توجد محادثات بعد</p>
              <p className="text-xs mt-1">ابدأ محادثة جديدة لتظهر هنا</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ChatSidebar;