import { useState, useCallback } from "react";
import { Upload, File, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileData } from "@/lib/luxuryAI";

interface FileUploadProps {
  onFileSelect: (file: FileData) => void;
  currentFile?: FileData;
  onRemoveFile: () => void;
}

const FileUpload = ({ onFileSelect, currentFile, onRemoveFile }: FileUploadProps) => {
  const [dragOver, setDragOver] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      processFile(files[0]);
    }
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  }, []);

  const processFile = async (file: File) => {
    try {
      const content = await file.text();
      const fileData: FileData = {
        name: file.name,
        type: file.type,
        content,
        size: file.size
      };
      onFileSelect(fileData);
    } catch (error) {
      console.error('Error reading file:', error);
    }
  };

  if (currentFile) {
    return (
      <div className="flex items-center space-x-2 bg-gradient-card border border-primary/20 rounded-lg p-2">
        <div className="p-1 bg-primary/10 rounded">
          <File className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">{currentFile.name}</p>
          <p className="text-xs text-muted-foreground">
            {(currentFile.size / 1024).toFixed(1)} KB
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRemoveFile}
          className="text-muted-foreground hover:text-destructive h-6 w-6 p-0"
        >
          <X className="w-3 h-3" />
        </Button>
      </div>
    );
  }

  return (
    <Button
      variant="outline"
      className={`relative bg-gradient-card border-dashed border-2 transition-all duration-300 h-12 px-4 ${
        dragOver ? 'border-primary shadow-glow' : 'border-border'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => document.getElementById('file-input')?.click()}
    >
      <div className="flex items-center space-x-2">
        <div className={`p-1 rounded transition-colors ${dragOver ? 'bg-primary/20' : 'bg-primary/10'}`}>
          <Upload className="w-4 h-4 text-primary" />
        </div>
        <span className="text-sm text-muted-foreground">
          {dragOver ? 'أفلت الملف هنا' : 'ارفع ملف'}
        </span>
      </div>

      <input
        id="file-input"
        type="file"
        className="hidden"
        onChange={handleFileInput}
        accept=".lua,.js,.ts,.py,.java,.cpp,.c,.html,.css,.txt"
      />
    </Button>
  );
};

export default FileUpload;